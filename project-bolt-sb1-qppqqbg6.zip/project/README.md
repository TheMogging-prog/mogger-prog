# BuildTrack - Construction Material Tracking System

A modern, full-stack construction material tracking application built with Next.js, TypeScript, Tailwind CSS, and Supabase.

## Features

### Multi-Role System
- **Admin**: Complete system management, analytics, and oversight
- **Vendor**: Create and manage shipments, upload materials and bills
- **Driver**: Accept assignments, track trips with GPS, mark deliveries complete
- **Site Manager**: Receive shipments, upload received photos/documents, confirm/reject deliveries

### Core Functionality
- Real-time shipment tracking with GPS location updates
- File uploads for material photos and bills/invoices
- Role-based access control with Row Level Security
- Interactive dashboards with analytics
- Full CRUD operations for all entities
- Responsive design with dark mode support

## Tech Stack

- **Frontend**: Next.js 13, TypeScript, Tailwind CSS
- **UI Components**: shadcn/ui
- **Database**: PostgreSQL (Supabase)
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage
- **Edge Functions**: Deno/Supabase Edge Runtime
- **Charts**: Recharts

## Getting Started

### 1. Set up the Database

The database schema is already configured. The following tables are created:
- `profiles` - User accounts with roles
- `vendors` - Vendor company information
- `drivers` - Driver details and vehicles
- `sites` - Construction sites
- `shipments` - Main tracking table
- `shipment_materials` - Materials per shipment
- `shipment_photos` - Photo uploads
- `shipment_bills` - Bill/invoice uploads
- `shipment_tracking` - GPS location history
- `delivery_confirmations` - Site manager confirmations

### 2. Initialize Default Users

Call the setup edge function to create demo accounts:

```bash
curl -X POST https://pqybpqcugftmxrmdyinn.supabase.co/functions/v1/setup-admin
```

Or visit the endpoint in your browser.

### 3. Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@buildtrack.com | Admin@123 |
| Vendor | vendor@example.com | Vendor@123 |
| Driver | driver@example.com | Driver@123 |
| Site Manager | sitemanager@example.com | Site@123 |

### 4. Run the Development Server

```bash
npm run dev
```

Visit `http://localhost:3000` and log in with any of the demo accounts.

## Application Structure

```
app/
├── dashboard/
│   ├── page.tsx                # Role-based dashboard
│   ├── shipments/
│   │   ├── page.tsx           # Shipments list
│   │   ├── create/page.tsx    # Create new shipment
│   │   └── [id]/page.tsx      # Shipment details
│   ├── assignments/page.tsx  # Driver assignments
│   ├── trip/page.tsx          # Active trip view
│   ├── incoming/page.tsx      # Incoming shipments
│   ├── receiving/
│   │   ├── page.tsx           # Pending confirmations
│   │   └── [id]/page.tsx      # Confirm delivery
│   ├── vendors/page.tsx       # Admin: Manage vendors
│   ├── drivers/page.tsx       # Admin: Manage drivers
│   └── sites/page.tsx         # Admin: Manage sites
├── login/page.tsx
├── signup/page.tsx
└── layout.tsx                 # Root layout with AuthProvider

components/
├── layout/
│   ├── sidebar.tsx           # Navigation sidebar
│   └── navbar.tsx            # Top navigation
└── dashboards/
    ├── admin-dashboard.tsx
    ├── vendor-dashboard.tsx
    ├── driver-dashboard.tsx
    └── site-manager-dashboard.tsx

lib/
├── supabase.ts               # Supabase client
├── auth-context.tsx          # Authentication context
├── auth-middleware.tsx       # Role-based route protection
└── types/
    ├── database.ts           # Database types
    └── index.ts              # Application types

supabase/
└── functions/
    └── setup-admin/         # Edge function for initialization
```

## User Workflows

### Vendor Workflow
1. Create a new shipment
2. Add materials with quantities and prices
3. Upload material photos
4. Upload bill/invoice
5. Assign driver (optional)
6. Select destination site
7. Track shipment status

### Driver Workflow
1. View assigned shipments
2. Accept shipment (status: loading)
3. Start trip (status: in_transit, GPS tracking begins)
4. Arrive at site
5. Mark as delivered
6. GPS location auto-updates every 30 seconds

### Site Manager Workflow
1. View incoming shipments
2. See delivered shipments pending confirmation
3. Review shipment details and materials
4. Upload received photos
5. Upload received bill
6. Capture GPS location
7. Confirm or reject delivery

### Admin Workflow
1. View all shipments and statistics
2. Monitor vendor performance
3. Verify/unverify vendors
4. Manage driver availability
5. Oversee all construction sites
6. View analytics dashboard

## Security Features

- Row Level Security (RLS) on all tables
- Role-based access control
- JWT authentication
- Protected API routes
- GPS location capture for deliveries
- Upload verification

## Environment Variables

All required environment variables are pre-configured in the Supabase project:

```
NEXT_PUBLIC_SUPABASE_URL=https://pqybpqcugftmxrmdyinn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<your-anon-key>
```

## Deployment

The application is ready for deployment on:
- Vercel (recommended for Next.js)
- Netlify
- Replit
- Bolt.new

Simply connect your repository and deploy. The build is optimized and production-ready.

## License

MIT
