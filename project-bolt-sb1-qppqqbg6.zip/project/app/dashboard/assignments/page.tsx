'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, Truck, Calendar, MapPin, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function DriverAssignmentsPage() {
  const { driver } = useAuth();
  const [assignments, setAssignments] = useState<ShipmentWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (driver) {
      fetchAssignments();
    }
  }, [driver]);

  const fetchAssignments = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*),
        sites!shipments_site_id_fkey (*),
        shipment_materials (*)
      `)
      .eq('driver_id', driver?.id)
      .in('status', ['loading', 'in_transit'])
      .order('created_at', { ascending: true });

    if (!error && data) {
      setAssignments(data as ShipmentWithDetails[]);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Assigned Shipments</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Your pending and active deliveries
        </p>
      </div>

      <div className="grid gap-4">
        {assignments.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No active assignments</p>
            </CardContent>
          </Card>
        ) : (
          assignments.map((assignment) => (
            <Link
              key={assignment.id}
              href={`/dashboard/shipments/${assignment.id}`}
              className="block"
            >
              <Card className="hover:shadow-lg transition-all cursor-pointer hover:border-blue-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-lg ${
                        assignment.status === 'loading'
                          ? 'bg-orange-100 dark:bg-orange-900'
                          : 'bg-blue-100 dark:bg-blue-900'
                      }`}>
                        <Package className={`h-6 w-6 ${
                          assignment.status === 'loading'
                            ? 'text-orange-600 dark:text-orange-400'
                            : 'text-blue-600 dark:text-blue-400'
                        }`} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {assignment.shipment_number}
                        </h3>
                        <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {format(new Date(assignment.created_at), 'MMM dd, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Truck className="h-4 w-4" />
                            {assignment.truck_number || 'N/A'}
                          </div>
                          {(assignment as any).sites && (
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {(assignment as any).sites.site_name}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <Badge
                        variant={assignment.status === 'in_transit' ? 'default' : 'secondary'}
                        className={assignment.status === 'loading'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-blue-100 text-blue-800'
                        }
                      >
                        {assignment.status === 'loading' ? 'Ready for Pickup' : 'In Transit'}
                      </Badge>
                      <div className="text-right">
                        <p className="text-lg font-bold text-gray-900 dark:text-white">
                          ${assignment.total_amount?.toLocaleString() || 0}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(assignment as any).shipment_materials?.length || 0} materials
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
