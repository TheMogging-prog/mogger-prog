'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Driver, Profile } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, Truck, CheckCircle, MapPin } from 'lucide-react';

interface DriverWithProfile extends Driver {
  profiles?: Profile;
}

export default function DriversPage() {
  const [drivers, setDrivers] = useState<DriverWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchDrivers();
  }, []);

  const fetchDrivers = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('drivers')
      .select('*, profiles!drivers_profile_id_fkey (*)')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setDrivers(data as DriverWithProfile[]);
    }

    setLoading(false);
  };

  const filteredDrivers = drivers.filter(
    (d) =>
      d.profiles?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.vehicle_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.profiles?.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Drivers</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage driver accounts and availability
        </p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search drivers..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDrivers.map((driver) => (
          <Card key={driver.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center">
                    <span className="text-sm font-medium text-white">
                      {driver.profiles?.full_name?.charAt(0).toUpperCase() || 'D'}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      {driver.profiles?.full_name || 'Driver'}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {driver.profiles?.email}
                    </p>
                  </div>
                </div>
                <Badge
                  variant={driver.is_available ? 'default' : 'secondary'}
                  className={driver.is_available ? 'bg-green-100 text-green-800' : ''}
                >
                  {driver.is_available ? 'Available' : 'Busy'}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Truck className="h-4 w-4" />
                  <span>{driver.vehicle_number || 'N/A'}</span>
                  <span className="text-gray-400">•</span>
                  <span>{driver.vehicle_type || 'N/A'}</span>
                </div>
                {driver.license_number && (
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <CheckCircle className="h-4 w-4" />
                    <span>License: {driver.license_number}</span>
                  </div>
                )}
                {driver.current_location &&
                  (driver.current_location as any).latitude && (
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <MapPin className="h-4 w-4" />
                      <span className="font-mono text-xs">
                        {(driver.current_location as any).latitude.toFixed(4)},{' '}
                        {(driver.current_location as any).longitude.toFixed(4)}
                      </span>
                    </div>
                  )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
