'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Package, Truck, Calendar, MapPin, Clock } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function IncomingShipmentsPage() {
  const { site } = useAuth();
  const [incoming, setIncoming] = useState<ShipmentWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (site) {
      fetchIncoming();
    }
  }, [site]);

  const fetchIncoming = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*),
        drivers!shipments_driver_id_fkey (*, profiles!drivers_profile_id_fkey (*)),
        shipment_materials (*)
      `)
      .eq('site_id', site?.id)
      .in('status', ['in_transit', 'delivered'])
      .order('created_at', { ascending: false });

    if (!error && data) {
      setIncoming(data as ShipmentWithDetails[]);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const pendingConfirmation = incoming.filter((s) => s.status === 'delivered');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Incoming Shipments</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          View shipments en route to your site
        </p>
      </div>

      {/* Pending Confirmation Alert */}
      {pendingConfirmation.length > 0 && (
        <Card className="border-2 border-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="bg-orange-100 dark:bg-orange-900 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {pendingConfirmation.length} Shipment{pendingConfirmation.length > 1 ? 's' : ''} Awaiting Confirmation
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Review and confirm delivered shipments
                </p>
              </div>
              <Link href="/dashboard/receiving">
                <Button className="bg-orange-600 hover:bg-orange-700">Review Now</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Shipments List */}
      <div className="grid gap-4">
        {incoming.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No incoming shipments</p>
            </CardContent>
          </Card>
        ) : (
          incoming.map((shipment) => (
            <Link
              key={shipment.id}
              href={`/dashboard/shipments/${shipment.id}`}
              className="block"
            >
              <Card className="hover:shadow-lg transition-all cursor-pointer hover:border-blue-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div
                        className={`p-3 rounded-lg ${
                          shipment.status === 'delivered'
                            ? 'bg-green-100 dark:bg-green-900'
                            : 'bg-blue-100 dark:bg-blue-900'
                        }`}
                      >
                        <Package
                          className={`h-6 w-6 ${
                            shipment.status === 'delivered'
                              ? 'text-green-600 dark:text-green-400'
                              : 'text-blue-600 dark:text-blue-400'
                          }`}
                        />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {shipment.shipment_number}
                        </h3>
                        <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {format(new Date(shipment.created_at), 'MMM dd, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Truck className="h-4 w-4" />
                            {shipment.truck_number || 'N/A'}
                          </div>
                          {(shipment as any).vendors && (
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {(shipment as any).vendors.company_name}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <Badge
                        variant={shipment.status === 'delivered' ? 'default' : 'secondary'}
                        className={
                          shipment.status === 'delivered'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-blue-100 text-blue-800'
                        }
                      >
                        {shipment.status === 'delivered' ? 'Ready for Confirmation' : 'In Transit'}
                      </Badge>
                      <div className="text-right">
                        <p className="text-lg font-bold text-gray-900 dark:text-white">
                          ${shipment.total_amount?.toLocaleString() || 0}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(shipment as any).shipment_materials?.length || 0} materials
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
