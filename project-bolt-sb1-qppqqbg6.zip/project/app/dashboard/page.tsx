'use client';

import DashboardLayout from './layout';
import AdminDashboard from '@/components/dashboards/admin-dashboard';
import VendorDashboard from '@/components/dashboards/vendor-dashboard';
import DriverDashboard from '@/components/dashboards/driver-dashboard';
import SiteManagerDashboard from '@/components/dashboards/site-manager-dashboard';
import { useAuth } from '@/lib/auth-context';

export default function DashboardPage() {
  const { profile, loading } = useAuth();

  if (loading || !profile) {
    return null;
  }

  const role = profile.role;

  return (
    <>
      {role === 'admin' && <AdminDashboard />}
      {role === 'vendor' && <VendorDashboard />}
      {role === 'driver' && <DriverDashboard />}
      {role === 'site_manager' && <SiteManagerDashboard />}
    </>
  );
}
