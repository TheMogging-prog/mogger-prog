'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import {
  Package,
  CheckCircle2,
  XCircle,
  Upload,
  MapPin,
  Camera,
  FileText,
  ArrowLeft,
  X,
} from 'lucide-react';
import { format } from 'date-fns';

export default function ReceivingDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { profile } = useAuth();
  const { toast } = useToast();

  const [shipment, setShipment] = useState<ShipmentWithDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [notes, setNotes] = useState('');
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [receivedPhotos, setReceivedPhotos] = useState<File[]>([]);
  const [receivedBill, setReceivedBill] = useState<File | null>(null);

  useEffect(() => {
    if (params.id) {
      fetchShipment();
      getCurrentLocation();
    }
  }, [params.id]);

  const fetchShipment = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*),
        drivers!shipments_driver_id_fkey (*, profiles!drivers_profile_id_fkey (*)),
        sites!shipments_site_id_fkey (*),
        shipment_materials (*),
        shipment_photos (*),
        shipment_bills (*)
      `)
      .eq('id', params.id)
      .single();

    if (!error && data) {
      setShipment(data as ShipmentWithDetails);
    }

    setLoading(false);
  };

  const getCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        },
        { enableHighAccuracy: true }
      );
    }
  };

  const uploadFile = async (file: File, bucket: string, path: string): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${path}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage.from(bucket).upload(fileName, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return null;
    }

    const { data } = supabase.storage.from(bucket).getPublicUrl(fileName);

    return data.publicUrl;
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setReceivedPhotos([...receivedPhotos, ...files]);
    }
  };

  const handleBillUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setReceivedBill(e.target.files[0]);
    }
  };

  const handleConfirm = async (status: 'confirmed' | 'rejected') => {
    setConfirming(true);

    try {
      // Upload received photos
      if (receivedPhotos.length > 0) {
        for (const photo of receivedPhotos) {
          const photoUrl = await uploadFile(photo, 'shipment-photos', shipment!.id);
          if (photoUrl) {
            await supabase.from('shipment_photos').insert({
              shipment_id: shipment!.id,
              photo_url: photoUrl,
              photo_type: 'received',
              uploaded_by: profile?.id,
            });
          }
        }
      }

      // Upload received bill
      if (receivedBill) {
        const billUrl = await uploadFile(receivedBill, 'shipment-bills', shipment!.id);
        if (billUrl) {
          await supabase.from('shipment_bills').insert({
            shipment_id: shipment!.id,
            bill_url: billUrl,
            bill_type: 'received',
            uploaded_by: profile?.id,
          });
        }
      }

      // Create confirmation record
      await supabase.from('delivery_confirmations').insert({
        shipment_id: shipment!.id,
        site_manager_id: profile?.id,
        status,
        notes,
        gps_location: currentLocation
          ? { latitude: currentLocation.lat, longitude: currentLocation.lng }
          : null,
      });

      // Update shipment status
      await supabase
        .from('shipments')
        .update({ status })
        .eq('id', shipment!.id);

      toast({
        title: 'Success',
        description: `Shipment ${status === 'confirmed' ? 'confirmed' : 'rejected'} successfully`,
      });

      router.push('/dashboard/incoming');
    } catch (error: any) {
      console.error('Error confirming delivery:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to confirm delivery',
        variant: 'destructive',
      });
    }

    setConfirming(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!shipment) {
    return (
      <div className="text-center py-12">
        <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 dark:text-gray-400">Shipment not found</p>
      </div>
    );
  }

  const materials = (shipment as any).shipment_materials || [];
  const originalPhotos = (shipment as any).shipment_photos?.filter((p: any) => p.photo_type === 'material') || [];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Confirm Delivery</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">{shipment.shipment_number}</p>
        </div>
        <Badge className="bg-orange-100 text-orange-800">Pending Confirmation</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column - Shipment Details */}
        <div className="space-y-6">
          {/* Shipment Info */}
          <Card>
            <CardHeader>
              <CardTitle>Shipment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Truck Number</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {shipment.truck_number || 'N/A'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Vendor</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {(shipment as any).vendors?.company_name || 'N/A'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Driver</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {(shipment as any).drivers?.profiles?.full_name || 'N/A'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Delivered</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {shipment.actual_delivery
                    ? format(new Date(shipment.actual_delivery), 'MMM dd, yyyy HH:mm')
                    : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total</span>
                <span className="font-bold text-gray-900 dark:text-white">
                  ${shipment.total_amount?.toLocaleString() || 0}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Materials */}
          <Card>
            <CardHeader>
              <CardTitle>Materials</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {materials.map((material: any) => (
                  <div key={material.id} className="flex justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {material.material_name}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {material.material_type || 'Standard'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-900 dark:text-white">
                        {material.quantity} {material.unit}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        ${material.total_price?.toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Original Photos */}
          {originalPhotos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  Original Material Photos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  {originalPhotos.map((photo: any) => (
                    <img
                      key={photo.id}
                      src={photo.photo_url}
                      alt="Material"
                      className="w-full h-24 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column - Confirmation Form */}
        <div className="space-y-6">
          {/* Current Location */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Your Location
              </CardTitle>
              <CardDescription>GPS coordinates will be recorded</CardDescription>
            </CardHeader>
            <CardContent>
              {currentLocation ? (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Latitude</p>
                    <p className="font-mono text-gray-900 dark:text-white">
                      {currentLocation.lat.toFixed(6)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Longitude</p>
                    <p className="font-mono text-gray-900 dark:text-white">
                      {currentLocation.lng.toFixed(6)}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-600 dark:text-gray-400">Location not available</p>
              )}
            </CardContent>
          </Card>

          {/* Upload Photos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Received Material Photos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="hidden"
                  id="received-photos"
                />
                <label htmlFor="received-photos" className="cursor-pointer">
                  <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Upload photos of received materials
                  </p>
                </label>
              </div>
              {receivedPhotos.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {receivedPhotos.map((file, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-1">
                      {file.name}
                      <button
                        type="button"
                        onClick={() => setReceivedPhotos(receivedPhotos.filter((_, i) => i !== idx))}
                        className="hover:text-red-600"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upload Bill */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Received Bill/Invoice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleBillUpload}
                  className="hidden"
                  id="received-bill"
                />
                <label htmlFor="received-bill" className="cursor-pointer">
                  <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Upload received bill/invoice
                  </p>
                </label>
              </div>
              {receivedBill && (
                <Badge variant="secondary" className="mt-2">
                  {receivedBill.name}
                </Badge>
              )}
            </CardContent>
          </Card>

          {/* Notes */}
          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Add any notes about the delivery condition, discrepancies, etc..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="min-h-[100px]"
              />
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <Card>
            <CardContent className="p-6 space-y-4">
              <Button
                onClick={() => handleConfirm('confirmed')}
                disabled={confirming}
                className="w-full bg-green-600 hover:bg-green-700 h-12"
              >
                <CheckCircle2 className="h-5 w-5 mr-2" />
                Confirm Delivery
              </Button>
              <Button
                onClick={() => handleConfirm('rejected')}
                disabled={confirming}
                variant="destructive"
                className="w-full h-12"
              >
                <XCircle className="h-5 w-5 mr-2" />
                Reject Delivery
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
