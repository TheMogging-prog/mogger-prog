'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Package, Clock, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function ReceivingPage() {
  const { site } = useAuth();
  const [pendingDeliveries, setPendingDeliveries] = useState<ShipmentWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (site) {
      fetchDeliveries();
    }
  }, [site]);

  const fetchDeliveries = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*),
        drivers!shipments_driver_id_fkey (*, profiles!drivers_profile_id_fkey (*)),
        shipment_materials (*),
        shipment_photos (*)
      `)
      .eq('site_id', site?.id)
      .eq('status', 'delivered')
      .order('actual_delivery', { ascending: false });

    if (!error && data) {
      setPendingDeliveries(data as ShipmentWithDetails[]);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Receiving</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Confirm or reject delivered shipments
        </p>
      </div>

      {pendingDeliveries.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <p className="text-gray-600 dark:text-gray-400">
              All deliveries confirmed. No pending shipments.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {pendingDeliveries.map((shipment) => (
            <Card key={shipment.id} className="border-2 border-orange-300">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-orange-100 dark:bg-orange-900 p-3 rounded-lg">
                      <Package className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {shipment.shipment_number}
                        </h3>
                        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                          Pending Confirmation
                        </Badge>
                      </div>
                      <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <p>
                          Delivered:{' '}
                          {shipment.actual_delivery
                            ? format(new Date(shipment.actual_delivery), 'MMM dd, yyyy HH:mm')
                            : 'N/A'}
                        </p>
                        <p>Driver: {(shipment as any).drivers?.profiles?.full_name || 'N/A'}</p>
                        <p>Materials: {(shipment as any).shipment_materials?.length || 0}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Link href={`/dashboard/receiving/${shipment.id}`}>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        Review & Confirm
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
