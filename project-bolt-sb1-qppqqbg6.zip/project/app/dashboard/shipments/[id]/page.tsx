'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import {
  Package,
  Truck,
  MapPin,
  Calendar,
  Clock,
  User,
  Building2,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  PackageCheck,
  Navigation
} from 'lucide-react';
import { format } from 'date-fns';
import Link from 'next/link';

export default function ShipmentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { profile, driver, vendor } = useAuth();
  const { toast } = useToast();

  const [shipment, setShipment] = useState<ShipmentWithDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (params.id) {
      fetchShipment();
    }
  }, [params.id]);

  const fetchShipment = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*, profiles!vendors_profile_id_fkey (*)),
        drivers!shipments_driver_id_fkey (*, profiles!drivers_profile_id_fkey (*)),
        sites!shipments_site_id_fkey (*, profiles!sites_manager_id_fkey (*)),
        shipment_materials (*),
        shipment_photos (*),
        shipment_bills (*),
        shipment_tracking (*),
        delivery_confirmations (*)
      `)
      .eq('id', params.id)
      .single();

    if (!error && data) {
      setShipment(data as ShipmentWithDetails);
    }

    setLoading(false);
  };

  const updateShipmentStatus = async (newStatus: string) => {
    setUpdating(true);

    const updateData: any = { status: newStatus };

    if (newStatus === 'in_transit') {
      // Driver starts trip
      if (driver) {
        const { data: driverData } = await supabase
          .from('drivers')
          .select('id')
          .eq('profile_id', profile?.id)
          .single();

        if (driverData) {
          updateData.driver_id = driverData.id;
        }
      }
    }

    if (newStatus === 'delivered') {
      updateData.actual_delivery = new Date().toISOString();
    }

    const { error } = await supabase
      .from('shipments')
      .update(updateData)
      .eq('id', params.id);

    if (!error) {
      toast({
        title: 'Success',
        description: `Shipment status updated to ${newStatus.replace('_', ' ')}`,
      });
      fetchShipment();
    } else {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }

    setUpdating(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'in_transit':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delivered':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'rejected':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'loading':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!shipment) {
    return (
      <div className="text-center py-12">
        <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 dark:text-gray-400">Shipment not found</p>
        <Button className="mt-4" onClick={() => router.back()}>
          Go back
        </Button>
      </div>
    );
  }

  const vendorData = (shipment as any).vendors;
  const driverData = (shipment as any).drivers;
  const siteData = (shipment as any).sites;
  const materials = (shipment as any).shipment_materials || [];
  const photos = (shipment as any).shipment_photos || [];
  const bills = (shipment as any).shipment_bills || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => router.back()}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {shipment.shipment_number}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Created on {format(new Date(shipment.created_at), 'MMMM dd, yyyy HH:mm')}
          </p>
        </div>
        <Badge className={`${getStatusColor(shipment.status)} text-base px-4 py-2`}>
          {shipment.status.replace('_', ' ')}
        </Badge>
      </div>

      {/* Status Actions */}
      {profile?.role === 'driver' && shipment.status === 'loading' && (
        <Card className="border-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  Ready to Start Trip?
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Click the button when you've loaded all materials
                </p>
              </div>
              <Button
                onClick={() => updateShipmentStatus('in_transit')}
                disabled={updating}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Navigation className="h-4 w-4 mr-2" />
                Start Trip
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {profile?.role === 'driver' && shipment.status === 'in_transit' && (
        <Card className="border-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  Arrived at Destination?
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Mark as delivered when you reach the site
                </p>
              </div>
              <Button
                onClick={() => updateShipmentStatus('delivered')}
                disabled={updating}
                className="bg-green-600 hover:bg-green-700"
              >
                <PackageCheck className="h-4 w-4 mr-2" />
                Mark Delivered
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Shipment Details */}
          <Card>
            <CardHeader>
              <CardTitle>Shipment Details</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Truck className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Truck Number</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {shipment.truck_number || 'N/A'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Calendar className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Estimated Delivery</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {shipment.estimated_delivery
                      ? format(new Date(shipment.estimated_delivery), 'MMM dd, yyyy')
                      : 'N/A'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Actual Delivery</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    {shipment.actual_delivery
                      ? format(new Date(shipment.actual_delivery), 'MMM dd, yyyy HH:mm')
                      : 'Pending'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Package className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Amount</p>
                  <p className="font-medium text-gray-900 dark:text-white">
                    ${shipment.total_amount?.toLocaleString() || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Materials */}
          <Card>
            <CardHeader>
              <CardTitle>Materials</CardTitle>
              <CardDescription>Items in this shipment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {materials.map((material: any) => (
                  <div
                    key={material.id}
                    className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {material.material_name}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {material.material_type || 'Standard'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900 dark:text-white">
                        {material.quantity} {material.unit}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        ${material.total_price?.toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Photos */}
          {photos.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5" />
                  Photos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  {photos.map((photo: any) => (
                    <div key={photo.id} className="relative group">
                      <img
                        src={photo.photo_url}
                        alt={photo.photo_type}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <Badge
                        variant="secondary"
                        className="absolute bottom-2 left-2 text-xs"
                      >
                        {photo.photo_type}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes */}
          {shipment.notes && (
            <Card>
              <CardHeader>
                <CardTitle>Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300">{shipment.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column - Participants */}
        <div className="space-y-6">
          {/* Vendor */}
          {vendorData && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Vendor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-medium text-gray-900 dark:text-white">
                  {vendorData.company_name}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {vendorData.company_address || 'No address'}
                </p>
                {vendorData.gst_number && (
                  <p className="text-sm text-gray-500 mt-2">GST: {vendorData.gst_number}</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Driver */}
          {driverData && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Driver
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-medium text-gray-900 dark:text-white">
                  {driverData.profiles?.full_name || 'Driver'}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {driverData.vehicle_type} - {driverData.vehicle_number}
                </p>
                {driverData.license_number && (
                  <p className="text-sm text-gray-500 mt-2">License: {driverData.license_number}</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Site */}
          {siteData && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Delivery Site
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-medium text-gray-900 dark:text-white">
                  {siteData.site_name}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {siteData.site_address || 'No address'}
                </p>
                <Badge variant="outline" className="mt-2">
                  {siteData.site_code}
                </Badge>
              </CardContent>
            </Card>
          )}

          {/* Bills */}
          {bills.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Bills/Invoices
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {bills.map((bill: any) => (
                  <a
                    key={bill.id}
                    href={bill.bill_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {bill.bill_type === 'original' ? 'Original Bill' : 'Received Bill'}
                      </p>
                      {bill.bill_number && (
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          #{bill.bill_number}
                        </p>
                      )}
                    </div>
                    <Badge variant="secondary">
                      ${bill.amount?.toLocaleString() || 0}
                    </Badge>
                  </a>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
