'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Driver, Site } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  Package,
  Plus,
  Trash2,
  Upload,
  Calendar,
  Truck,
  MapPin,
  X
} from 'lucide-react';

interface Material {
  material_name: string;
  material_type: string;
  quantity: number;
  unit: string;
  unit_price: number;
  description: string;
}

export default function CreateShipmentPage() {
  const { vendor } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(false);

  const [truckNumber, setTruckNumber] = useState('');
  const [selectedDriver, setSelectedDriver] = useState('');
  const [selectedSite, setSelectedSite] = useState('');
  const [estimatedDelivery, setEstimatedDelivery] = useState('');
  const [notes, setNotes] = useState('');
  const [materials, setMaterials] = useState<Material[]>([
    { material_name: '', material_type: '', quantity: 0, unit: 'tons', unit_price: 0, description: '' }
  ]);
  const [materialPhotos, setMaterialPhotos] = useState<File[]>([]);
  const [billFile, setBillFile] = useState<File | null>(null);

  useEffect(() => {
    fetchFormData();
  }, []);

  const fetchFormData = async () => {
    const [driversRes, sitesRes] = await Promise.all([
      supabase.from('drivers').select('*, profiles!drivers_profile_id_fkey(*)').eq('is_available', true),
      supabase.from('sites').select('*, profiles!sites_manager_id_fkey(*)').eq('is_active', true),
    ]);

    if (driversRes.data) setDrivers(driversRes.data);
    if (sitesRes.data) setSites(sitesRes.data);
  };

  const addMaterial = () => {
    setMaterials([
      ...materials,
      { material_name: '', material_type: '', quantity: 0, unit: 'tons', unit_price: 0, description: '' }
    ]);
  };

  const removeMaterial = (index: number) => {
    if (materials.length > 1) {
      setMaterials(materials.filter((_, i) => i !== index));
    }
  };

  const updateMaterial = (index: number, field: keyof Material, value: any) => {
    const updated = [...materials];
    updated[index] = { ...updated[index], [field]: value };
    setMaterials(updated);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setMaterialPhotos([...materialPhotos, ...files]);
    }
  };

  const handleBillUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setBillFile(e.target.files[0]);
    }
  };

  const uploadFile = async (file: File, bucket: string, path: string): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${path}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from(bucket)
      .upload(fileName, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return null;
    }

    const { data } = supabase.storage
      .from(bucket)
      .getPublicUrl(fileName);

    return data.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate materials
      const validMaterials = materials.filter(m => m.material_name && m.quantity > 0);
      if (validMaterials.length === 0) {
        toast({
          title: 'Error',
          description: 'Please add at least one material',
          variant: 'destructive',
        });
        setLoading(false);
        return;
      }

      // Calculate total amount
      const totalAmount = validMaterials.reduce((sum, m) => sum + (m.quantity * m.unit_price), 0);

      // Create shipment
      const { data: shipment, error: shipmentError } = await supabase
        .from('shipments')
        .insert({
          vendor_id: vendor?.id,
          driver_id: selectedDriver || null,
          site_id: selectedSite || null,
          truck_number: truckNumber,
          estimated_delivery: estimatedDelivery || null,
          notes,
          total_amount: totalAmount,
          status: 'loading',
        })
        .select()
        .single();

      if (shipmentError) throw shipmentError;

      // Add materials
      const materialsData = validMaterials.map(m => ({
        shipment_id: shipment.id,
        ...m,
        total_price: m.quantity * m.unit_price,
      }));

      const { error: materialsError } = await supabase
        .from('shipment_materials')
        .insert(materialsData);

      if (materialsError) throw materialsError;

      // Upload photos
      if (materialPhotos.length > 0) {
        for (const photo of materialPhotos) {
          const photoUrl = await uploadFile(photo, 'shipment-photos', shipment.id);
          if (photoUrl) {
            await supabase.from('shipment_photos').insert({
              shipment_id: shipment.id,
              photo_url: photoUrl,
              photo_type: 'material',
              uploaded_by: vendor?.profile_id,
            });
          }
        }
      }

      // Upload bill
      if (billFile) {
        const billUrl = await uploadFile(billFile, 'shipment-bills', shipment.id);
        if (billUrl) {
          await supabase.from('shipment_bills').insert({
            shipment_id: shipment.id,
            bill_url: billUrl,
            bill_type: 'original',
            uploaded_by: vendor?.profile_id,
          });
        }
      }

      toast({
        title: 'Success',
        description: 'Shipment created successfully!',
      });

      router.push('/dashboard/shipments');
    } catch (error: any) {
      console.error('Error creating shipment:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to create shipment',
        variant: 'destructive',
      });
    }

    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Create New Shipment</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Add details for your construction material shipment
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Shipment Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Shipment Details
            </CardTitle>
            <CardDescription>Basic information about this shipment</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="truckNumber">Truck Number *</Label>
                <div className="relative">
                  <Truck className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="truckNumber"
                    placeholder="MH12AB1234"
                    value={truckNumber}
                    onChange={(e) => setTruckNumber(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="estimatedDelivery">Estimated Delivery</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="estimatedDelivery"
                    type="datetime-local"
                    value={estimatedDelivery}
                    onChange={(e) => setEstimatedDelivery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="driver">Assign Driver</Label>
                <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select driver (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {drivers.map((driver) => (
                      <SelectItem key={driver.id} value={driver.id}>
                        {(driver as any).profiles?.full_name} - {driver.vehicle_number}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="site">Deliver To</Label>
                <Select value={selectedSite} onValueChange={setSelectedSite}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select site" />
                  </SelectTrigger>
                  <SelectContent>
                    {sites.map((site) => (
                      <SelectItem key={site.id} value={site.id}>
                        {site.site_name} ({site.site_code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Add any special instructions or notes..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Materials */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Materials</CardTitle>
                <CardDescription>Add materials to be shipped</CardDescription>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={addMaterial}>
                <Plus className="h-4 w-4 mr-2" />
                Add Material
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {materials.map((material, index) => (
              <div
                key={index}
                className="grid grid-cols-12 gap-3 items-start p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
              >
                <div className="col-span-4 space-y-2">
                  <Label className="text-xs">Material Name *</Label>
                  <Input
                    placeholder="Cement, Steel, etc."
                    value={material.material_name}
                    onChange={(e) => updateMaterial(index, 'material_name', e.target.value)}
                  />
                </div>

                <div className="col-span-2 space-y-2">
                  <Label className="text-xs">Type</Label>
                  <Input
                    placeholder="Grade, Brand"
                    value={material.material_type}
                    onChange={(e) => updateMaterial(index, 'material_type', e.target.value)}
                  />
                </div>

                <div className="col-span-2 space-y-2">
                  <Label className="text-xs">Quantity *</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={material.quantity}
                    onChange={(e) => updateMaterial(index, 'quantity', parseFloat(e.target.value) || 0)}
                  />
                </div>

                <div className="col-span-2 space-y-2">
                  <Label className="text-xs">Unit</Label>
                  <Select
                    value={material.unit}
                    onValueChange={(value) => updateMaterial(index, 'unit', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tons">Tons</SelectItem>
                      <SelectItem value="kg">Kg</SelectItem>
                      <SelectItem value="bags">Bags</SelectItem>
                      <SelectItem value="pieces">Pieces</SelectItem>
                      <SelectItem value="meters">Meters</SelectItem>
                      <SelectItem value="sqft">Sq Ft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-1 space-y-2">
                  <Label className="text-xs">Price</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={material.unit_price}
                    onChange={(e) => updateMaterial(index, 'unit_price', parseFloat(e.target.value) || 0)}
                  />
                </div>

                <div className="col-span-1 flex items-end justify-center pb-2">
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeMaterial(index)}
                    disabled={materials.length === 1}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}

            <div className="text-right">
              <p className="text-lg font-bold text-gray-900 dark:text-white">
                Total: ${materials.reduce((sum, m) => sum + (m.quantity * m.unit_price), 0).toLocaleString()}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Upload Documents */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Documents & Photos
            </CardTitle>
            <CardDescription>Upload material photos and bill/invoice</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Material Photos</Label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="hidden"
                  id="photos"
                />
                <label htmlFor="photos" className="cursor-pointer">
                  <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 dark:text-gray-400">
                    Click to upload material photos
                  </p>
                  <p className="text-sm text-gray-500">PNG, JPG up to 10MB each</p>
                </label>
              </div>
              {materialPhotos.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {materialPhotos.map((file, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-2">
                      {file.name}
                      <button
                        type="button"
                        onClick={() => setMaterialPhotos(materialPhotos.filter((_, i) => i !== idx))}
                        className="hover:text-red-600"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Bill/Invoice</Label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*,.pdf"
                  onChange={handleBillUpload}
                  className="hidden"
                  id="bill"
                />
                <label htmlFor="bill" className="cursor-pointer">
                  <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 dark:text-gray-400">
                    Click to upload bill/invoice
                  </p>
                  <p className="text-sm text-gray-500">PNG, JPG, PDF up to 10MB</p>
                </label>
              </div>
              {billFile && (
                <Badge variant="secondary" className="mt-2">
                  {billFile.name}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-end gap-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.back()}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700"
            disabled={loading}
          >
            {loading ? 'Creating...' : 'Create Shipment'}
          </Button>
        </div>
      </form>
    </div>
  );
}
