'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Package,
  Search,
  Filter,
  ChevronDown,
  Calendar,
  Truck,
  Building2,
  MapPin
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function ShipmentsPage() {
  const { profile, vendor } = useAuth();
  const [shipments, setShipments] = useState<ShipmentWithDetails[]>([]);
  const [filtered, setFiltered] = useState<ShipmentWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('');

  useEffect(() => {
    fetchShipments();
  }, [profile, vendor]);

  useEffect(() => {
    filterShipments();
  }, [shipments, searchTerm, statusFilter, dateFilter]);

  const fetchShipments = async () => {
    setLoading(true);

    let query = supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*, profiles!vendors_profile_id_fkey (*)),
        drivers!shipments_driver_id_fkey (*, profiles!drivers_profile_id_fkey (*)),
        sites!shipments_site_id_fkey (*, profiles!sites_manager_id_fkey (*)),
        shipment_materials (*)
      `)
      .order('created_at', { ascending: false });

    // Filter by vendor if user is vendor
    if (profile?.role === 'vendor' && vendor) {
      query = query.eq('vendor_id', vendor.id);
    }

    const { data, error } = await query;

    if (!error && data) {
      setShipments(data as ShipmentWithDetails[]);
    }

    setLoading(false);
  };

  const filterShipments = () => {
    let filtered = shipments;

    if (searchTerm) {
      filtered = filtered.filter(
        (s) =>
          s.shipment_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.truck_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (s as any).vendors?.company_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter && statusFilter !== 'all') {
      filtered = filtered.filter((s) => s.status === statusFilter);
    }

    if (dateFilter) {
      filtered = filtered.filter((s) =>
        format(new Date(s.created_at), 'yyyy-MM-dd') === dateFilter
      );
    }

    setFiltered(filtered);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'in_transit':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delivered':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'rejected':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'loading':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Shipments</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {profile?.role === 'vendor' ? 'Manage your shipments' : 'View all shipments'}
          </p>
        </div>
        {profile?.role === 'vendor' && (
          <Link href="/dashboard/shipments/create">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Package className="h-4 w-4 mr-2" />
              Create Shipment
            </Button>
          </Link>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search shipments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="loading">Loading</SelectItem>
                <SelectItem value="in_transit">In Transit</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>

            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-48"
            />
          </div>
        </CardContent>
      </Card>

      {/* Shipments List */}
      <div className="grid gap-4">
        {filtered.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No shipments found</p>
            </CardContent>
          </Card>
        ) : (
          filtered.map((shipment) => (
            <Link
              key={shipment.id}
              href={`/dashboard/shipments/${shipment.id}`}
              className="block"
            >
              <Card className="hover:shadow-lg transition-all cursor-pointer hover:border-blue-300">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-lg">
                        <Package className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {shipment.shipment_number}
                        </h3>
                        <div className="flex flex-wrap gap-4 mt-2 text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {format(new Date(shipment.created_at), 'MMM dd, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Truck className="h-4 w-4" />
                            {shipment.truck_number || 'N/A'}
                          </div>
                          {(shipment as any).vendors && (
                            <div className="flex items-center gap-1">
                              <Building2 className="h-4 w-4" />
                              {(shipment as any).vendors.company_name}
                            </div>
                          )}
                          {(shipment as any).sites && (
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {(shipment as any).sites.site_name}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <Badge className={getStatusColor(shipment.status)}>
                        {shipment.status.replace('_', ' ')}
                      </Badge>
                      <div className="text-right">
                        <p className="text-lg font-bold text-gray-900 dark:text-white">
                          ${shipment.total_amount?.toLocaleString() || 0}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(shipment as any).shipment_materials?.length || 0} materials
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
