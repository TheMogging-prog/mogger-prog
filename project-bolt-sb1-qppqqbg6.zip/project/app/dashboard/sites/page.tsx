'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Site, Profile } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, MapPin, Building2, Users } from 'lucide-react';

interface SiteWithManager extends Site {
  manager?: Profile;
}

export default function SitesPage() {
  const [sites, setSites] = useState<SiteWithManager[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchSites();
  }, []);

  const fetchSites = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('sites')
      .select('*, profiles!sites_manager_id_fkey (*)')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setSites(data as SiteWithManager[]);
    }

    setLoading(false);
  };

  const filteredSites = sites.filter(
    (s) =>
      s.site_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.site_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.site_address?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Sites</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage construction sites
        </p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search sites..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSites.map((site) => (
          <Card key={site.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="bg-orange-100 dark:bg-orange-900 p-2 rounded-lg">
                    <Building2 className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      {site.site_name}
                    </h3>
                    <Badge variant="outline">{site.site_code}</Badge>
                  </div>
                </div>
                <Badge
                  variant={site.is_active ? 'default' : 'secondary'}
                  className={site.is_active ? 'bg-green-100 text-green-800' : ''}
                >
                  {site.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </div>

              <div className="space-y-2">
                {site.site_address && (
                  <div className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <MapPin className="h-4 w-4 mt-0.5" />
                    <span>{site.site_address}</span>
                  </div>
                )}
                {site.manager && (
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <Users className="h-4 w-4" />
                    <span>{site.manager.full_name}</span>
                  </div>
                )}
                {site.gps_coordinates && (site.gps_coordinates as any).latitude && (
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <MapPin className="h-4 w-4" />
                    <span className="font-mono text-xs">
                      {(site.gps_coordinates as any).latitude.toFixed(4)},{' '}
                      {(site.gps_coordinates as any).longitude.toFixed(4)}
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
