'use client';

import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { ShipmentWithDetails, ShipmentTracking } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import {
  Package,
  Truck,
  MapPin,
  Navigation,
  Clock,
  Battery,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { format } from 'date-fns';

export default function TripPage() {
  const { driver, profile } = useAuth();
  const { toast } = useToast();
  const [activeTrip, setActiveTrip] = useState<ShipmentWithDetails | null>(null);
  const [tracking, setTracking] = useState<ShipmentTracking[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (driver) {
      fetchActiveTrip();
    }
  }, [driver]);

  const fetchActiveTrip = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select(`
        *,
        vendors!shipments_vendor_id_fkey (*),
        sites!shipments_site_id_fkey (*),
        shipment_materials (*)
      `)
      .eq('driver_id', driver?.id)
      .in('status', ['loading', 'in_transit'])
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!error && data) {
      setActiveTrip(data as ShipmentWithDetails);

      // Fetch tracking history
      const { data: trackingData } = await supabase
        .from('shipment_tracking')
        .select('*')
        .eq('shipment_id', data.id)
        .order('recorded_at', { ascending: false })
        .limit(50);

      if (trackingData) {
        setTracking(trackingData);
      }
    }

    setLoading(false);
  };

  const updateLocation = useCallback(async () => {
    if (!activeTrip || !driver || !currentLocation) return;

    await supabase.from('shipment_tracking').insert({
      shipment_id: activeTrip.id,
      driver_id: driver.id,
      latitude: currentLocation.lat,
      longitude: currentLocation.lng,
    });

    // Update driver's current location
    await supabase
      .from('drivers')
      .update({
        current_location: {
          latitude: currentLocation.lat,
          longitude: currentLocation.lng,
        },
      })
      .eq('id', driver.id);
  }, [activeTrip, driver, currentLocation]);

  useEffect(() => {
    if (activeTrip?.status === 'in_transit') {
      // Get current location
      if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setCurrentLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.error('Error getting location:', error);
          },
          { enableHighAccuracy: true }
        );

        // Update location every 30 seconds
        const interval = setInterval(() => {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              setCurrentLocation({
                lat: position.coords.latitude,
                lng: position.coords.longitude,
              });
              updateLocation();
            },
            (error) => console.error('Location error:', error),
            { enableHighAccuracy: true }
          );
        }, 30000);

        return () => clearInterval(interval);
      }
    }
  }, [activeTrip?.status, updateLocation]);

  const startTrip = async () => {
    if (!activeTrip) return;

    const { error } = await supabase
      .from('shipments')
      .update({ status: 'in_transit' })
      .eq('id', activeTrip.id);

    if (!error) {
      toast({
        title: 'Trip Started',
        description: 'Your location is now being tracked',
      });
      fetchActiveTrip();
    }
  };

  const markDelivered = async () => {
    if (!activeTrip) return;

    const { error } = await supabase
      .from('shipments')
      .update({
        status: 'delivered',
        actual_delivery: new Date().toISOString(),
      })
      .eq('id', activeTrip.id);

    if (!error) {
      toast({
        title: 'Delivered',
        description: 'Shipment marked as delivered',
      });
      fetchActiveTrip();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!activeTrip) {
    return (
      <div className="text-center py-12">
        <Truck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600 dark:text-gray-400">No active trip</p>
      </div>
    );
  }

  const siteData = (activeTrip as any).sites;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Active Trip</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {activeTrip.shipment_number}
          </p>
        </div>
        <Badge
          variant={activeTrip.status === 'in_transit' ? 'default' : 'secondary'}
          className={activeTrip.status === 'loading' ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'}
        >
          {activeTrip.status === 'loading' ? 'Ready to Start' : 'In Transit'}
        </Badge>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Package className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Materials</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {(activeTrip as any).shipment_materials?.length || 0}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Navigation className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Location Status</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {currentLocation ? 'GPS Active' : 'GPS Off'}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <MapPin className="h-8 w-8 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Destination</p>
                  <p className="text-sm font-bold text-gray-900 dark:text-white">
                    {siteData?.site_name || 'N/A'}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      {activeTrip.status === 'loading' && (
        <Card className="border-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  Ready to Start?
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Make sure all materials are loaded before starting
                </p>
              </div>
              <Button onClick={startTrip} className="bg-orange-600 hover:bg-orange-700">
                <Navigation className="h-4 w-4 mr-2" />
                Start Trip
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTrip.status === 'in_transit' && (
        <Card className="border-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Arrived at Destination?
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Mark shipment as delivered when you reach the site
                </p>
              </div>
              <Button onClick={markDelivered} className="bg-green-600 hover:bg-green-700">
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Mark Delivered
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Location */}
      {currentLocation && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5" />
              Current Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Latitude</p>
                <p className="font-mono text-gray-900 dark:text-white">
                  {currentLocation.lat.toFixed(6)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Longitude</p>
                <p className="font-mono text-gray-900 dark:text-white">
                  {currentLocation.lng.toFixed(6)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Destination Details */}
      {siteData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Destination
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="font-medium text-gray-900 dark:text-white">{siteData.site_name}</p>
              <p className="text-gray-600 dark:text-gray-400">{siteData.site_address}</p>
              <Badge variant="outline">{siteData.site_code}</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tracking History */}
      {tracking.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Location History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {tracking.slice(0, 10).map((point) => (
                <div key={point.id} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">
                    {format(new Date(point.recorded_at), 'MMM dd, HH:mm:ss')}
                  </span>
                  <span className="font-mono text-gray-900 dark:text-white">
                    {point.latitude.toFixed(4)}, {point.longitude.toFixed(4)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
