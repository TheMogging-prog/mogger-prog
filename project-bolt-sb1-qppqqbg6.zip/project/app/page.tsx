'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Building2 } from 'lucide-react';

export default function HomePage() {
  const { profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && profile) {
      router.push('/dashboard');
    } else if (!loading && !profile) {
      router.push('/login');
    }
  }, [profile, loading, router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-white">
      <div className="text-center">
        <div className="bg-blue-600 p-4 rounded-full inline-block mb-4">
          <Building2 className="h-12 w-12 text-white animate-pulse" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-2">BuildTrack</h1>
        <p className="text-gray-600">Loading...</p>
      </div>
    </div>
  );
}
