'use client';

import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

export default function UnauthorizedPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-red-600 mb-4">403</h1>
        <p className="text-xl text-gray-900 mb-2">Access Denied</p>
        <p className="text-gray-600 mb-6">
          You don't have permission to access this page.
        </p>
        <Button onClick={() => router.push('/dashboard')}>Go to Dashboard</Button>
      </div>
    </div>
  );
}
