'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Shipment, Vendor, Driver, Site } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Package,
  Truck,
  Building2,
  MapPin,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { format, subDays } from 'date-fns';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function AdminDashboard() {
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);

    const [shipmentsRes, vendorsRes, driversRes, sitesRes] = await Promise.all([
      supabase.from('shipments').select('*').order('created_at', { ascending: false }).limit(100),
      supabase.from('vendors').select('*'),
      supabase.from('drivers').select('*'),
      supabase.from('sites').select('*'),
    ]);

    if (shipmentsRes.data) setShipments(shipmentsRes.data);
    if (vendorsRes.data) setVendors(vendorsRes.data);
    if (driversRes.data) setDrivers(driversRes.data);
    if (sitesRes.data) setSites(sitesRes.data);

    setLoading(false);
  };

  // Calculate statistics
  const totalShipments = shipments.length;
  const loadingCount = shipments.filter(s => s.status === 'loading').length;
  const inTransitCount = shipments.filter(s => s.status === 'in_transit').length;
  const deliveredCount = shipments.filter(s => s.status === 'delivered').length;
  const confirmedCount = shipments.filter(s => s.status === 'confirmed').length;
  const rejectedCount = shipments.filter(s => s.status === 'rejected').length;

  const activeDrivers = drivers.filter(d => d.is_available).length;
  const activeSites = sites.filter(s => s.is_active).length;
  const verifiedVendors = vendors.filter(v => v.is_verified).length;

  // Prepare chart data
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayShipments = shipments.filter(s =>
      format(new Date(s.created_at), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
    return {
      date: format(date, 'EEE'),
      shipments: dayShipments.length,
      confirmed: dayShipments.filter(s => s.status === 'confirmed').length,
    };
  });

  const statusData = [
    { name: 'Loading', value: loadingCount, color: COLORS[0] },
    { name: 'In Transit', value: inTransitCount, color: COLORS[1] },
    { name: 'Delivered', value: deliveredCount, color: COLORS[4] },
    { name: 'Confirmed', value: confirmedCount, color: COLORS[2] },
    { name: 'Rejected', value: rejectedCount, color: COLORS[3] },
  ].filter(item => item.value > 0);

  const vendorPerformance = vendors.slice(0, 5).map(vendor => {
    const vendorShipments = shipments.filter(s => s.vendor_id === vendor.id);
    return {
      name: vendor.company_name.substring(0, 15),
      shipments: vendorShipments.length,
      confirmed: vendorShipments.filter(s => s.status === 'confirmed').length,
    };
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">Overview of all construction material tracking</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Shipments</CardTitle>
            <Package className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{totalShipments}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              {loadingCount} loading, {inTransitCount} in transit
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Drivers</CardTitle>
            <Truck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{activeDrivers}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              of {drivers.length} total drivers
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Verified Vendors</CardTitle>
            <Building2 className="h-5 w-5 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{verifiedVendors}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              of {vendors.length} registered vendors
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Sites</CardTitle>
            <MapPin className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{activeSites}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Construction sites managed
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Shipment Trends (Last 7 Days)</CardTitle>
            <CardDescription>Daily shipment creation and confirmations</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={last7Days}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip />
                <Line type="monotone" dataKey="shipments" stroke="#3b82f6" strokeWidth={2} />
                <Line type="monotone" dataKey="confirmed" stroke="#10b981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Shipment Status Distribution</CardTitle>
            <CardDescription>Current status breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Vendor Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Vendor Performance</CardTitle>
          <CardDescription>Top vendors by shipment volume</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={vendorPerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip />
              <Bar dataKey="shipments" fill="#3b82f6" />
              <Bar dataKey="confirmed" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Recent Shipments */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Shipments</CardTitle>
          <CardDescription>Latest shipment activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {shipments.slice(0, 10).map((shipment) => (
              <div
                key={shipment.id}
                className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                    <Package className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{shipment.shipment_number}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {format(new Date(shipment.created_at), 'MMM dd, yyyy HH:mm')}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge
                    variant={
                      shipment.status === 'confirmed' ? 'default' :
                      shipment.status === 'in_transit' ? 'secondary' :
                      shipment.status === 'rejected' ? 'destructive' :
                      'outline'
                    }
                    className="capitalize"
                  >
                    {shipment.status.replace('_', ' ')}
                  </Badge>
                  {shipment.status === 'loading' && <Clock className="h-4 w-4 text-blue-600" />}
                  {shipment.status === 'in_transit' && <Truck className="h-4 w-4 text-green-600" />}
                  {shipment.status === 'confirmed' && <CheckCircle2 className="h-4 w-4 text-green-600" />}
                  {shipment.status === 'rejected' && <XCircle className="h-4 w-4 text-red-600" />}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
