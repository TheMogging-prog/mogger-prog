'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Shipment, Driver } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Package,
  Truck,
  MapPin,
  Clock,
  CheckCircle2,
  Navigation
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function DriverDashboard() {
  const { driver } = useAuth();
  const [assignedShipments, setAssignedShipments] = useState<Shipment[]>([]);
  const [activeTrip, setActiveTrip] = useState<Shipment | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (driver) {
      fetchShipments();
    }
  }, [driver]);

  const fetchShipments = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select('*')
      .eq('driver_id', driver?.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setAssignedShipments(data);
      const active = data.find(s => s.status === 'in_transit' || s.status === 'loading');
      setActiveTrip(active || null);
    }

    setLoading(false);
  };

  const pendingAssignments = assignedShipments.filter(s => s.status === 'loading').length;
  const completedTrips = assignedShipments.filter(s => s.status === 'delivered' || s.status === 'confirmed').length;
  const activeShipments = assignedShipments.filter(s => s.status === 'in_transit').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Driver Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Welcome back! Manage your deliveries
          </p>
        </div>
        {driver?.is_available && (
          <Badge variant="default" className="bg-green-600">
            Available for assignments
          </Badge>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Pickups</CardTitle>
            <Package className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{pendingAssignments}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Waiting to be picked up
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Trips</CardTitle>
            <Truck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{activeShipments}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Currently in transit
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Completed</CardTitle>
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{completedTrips}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Successfully delivered
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Vehicle</CardTitle>
            <Navigation className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-gray-900 dark:text-white">{driver?.vehicle_number}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              {driver?.vehicle_type}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Active Trip Card */}
      {activeTrip && (
        <Card className="border-2 border-blue-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-blue-600">Active Trip</CardTitle>
              <Badge variant="default" className="bg-blue-600">
                {activeTrip.status.replace('_', ' ')}
              </Badge>
            </div>
            <CardDescription>
              Shipment {activeTrip.shipment_number}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Truck Number</p>
                <p className="font-medium text-gray-900 dark:text-white">{activeTrip.truck_number}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Amount</p>
                <p className="font-medium text-gray-900 dark:text-white">${activeTrip.total_amount?.toLocaleString()}</p>
              </div>
            </div>
            <Link href="/dashboard/trip">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <MapPin className="h-4 w-4 mr-2" />
                Open Trip View
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}

      {/* Assigned Shipments */}
      <Card>
        <CardHeader>
          <CardTitle>Assigned Shipments</CardTitle>
          <CardDescription>Your current assignments</CardDescription>
        </CardHeader>
        <CardContent>
          {assignedShipments.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No shipments assigned yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {assignedShipments.slice(0, 10).map((shipment) => (
                <div
                  key={shipment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                      <Package className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">{shipment.shipment_number}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {format(new Date(shipment.created_at), 'MMM dd, yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <Badge
                    variant={
                      shipment.status === 'confirmed' ? 'default' :
                      shipment.status === 'in_transit' ? 'secondary' :
                      shipment.status === 'delivered' ? 'default' :
                      'outline'
                    }
                    className="capitalize"
                  >
                    {shipment.status.replace('_', ' ')}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
