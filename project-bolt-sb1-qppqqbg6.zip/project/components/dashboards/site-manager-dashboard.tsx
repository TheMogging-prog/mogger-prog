'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Shipment, Site } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Package,
  MapPin,
  Clock,
  CheckCircle2,
  XCircle,
  FileCheck
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function SiteManagerDashboard() {
  const { site } = useAuth();
  const [incomingShipments, setIncomingShipments] = useState<Shipment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (site) {
      fetchShipments();
    }
  }, [site]);

  const fetchShipments = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select('*')
      .eq('site_id', site?.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setIncomingShipments(data);
    }

    setLoading(false);
  };

  const inTransitCount = incomingShipments.filter(s => s.status === 'in_transit').length;
  const deliveredCount = incomingShipments.filter(s => s.status === 'delivered').length;
  const confirmedCount = incomingShipments.filter(s => s.status === 'confirmed').length;
  const rejectedCount = incomingShipments.filter(s => s.status === 'rejected').length;

  const pendingDeliveries = incomingShipments.filter(s => s.status === 'delivered');

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Site Manager Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {site?.site_name || 'Site'} - Manage incoming deliveries
          </p>
        </div>
        <Badge variant="default" className="bg-blue-600">
          {site?.site_code}
        </Badge>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">In Transit</CardTitle>
            <Package className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{inTransitCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Shipments on the way
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Confirmation</CardTitle>
            <Clock className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{deliveredCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Delivered, awaiting confirmation
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Confirmed</CardTitle>
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{confirmedCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Successfully received
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Rejected</CardTitle>
            <XCircle className="h-5 w-5 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{rejectedCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Delivery issues
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Pending Confirmations Alert */}
      {pendingDeliveries.length > 0 && (
        <Card className="border-2 border-orange-500">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-orange-600">Pending Confirmations</CardTitle>
              <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                {pendingDeliveries.length} shipments
              </Badge>
            </div>
            <CardDescription>
              These shipments have been delivered and require your confirmation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingDeliveries.slice(0, 3).map((shipment) => (
                <div
                  key={shipment.id}
                  className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-950 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <FileCheck className="h-5 w-5 text-orange-600" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">{shipment.shipment_number}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Delivered: {shipment.actual_delivery ? format(new Date(shipment.actual_delivery), 'MMM dd, yyyy HH:mm') : 'N/A'}
                      </p>
                    </div>
                  </div>
                  <Link href={`/dashboard/receiving/${shipment.id}`}>
                    <Button variant="outline" size="sm">
                      Review
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
            {pendingDeliveries.length > 3 && (
              <Link href="/dashboard/incoming">
                <Button variant="outline" className="w-full mt-4">
                  View all pending deliveries
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      )}

      {/* Incoming Shipments */}
      <Card>
        <CardHeader>
          <CardTitle>All Shipments</CardTitle>
          <CardDescription>Shipments for your site</CardDescription>
        </CardHeader>
        <CardContent>
          {incomingShipments.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No shipments yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {incomingShipments.slice(0, 10).map((shipment) => (
                <div
                  key={shipment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                      <Package className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">{shipment.shipment_number}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {format(new Date(shipment.created_at), 'MMM dd, yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge
                      variant={
                        shipment.status === 'confirmed' ? 'default' :
                        shipment.status === 'in_transit' ? 'secondary' :
                        shipment.status === 'delivered' ? 'outline' :
                        shipment.status === 'rejected' ? 'destructive' :
                        'outline'
                      }
                      className="capitalize"
                    >
                      {shipment.status.replace('_', ' ')}
                    </Badge>
                    {shipment.status === 'delivered' && (
                      <Link href={`/dashboard/receiving/${shipment.id}`}>
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          Confirm
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
