'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { Shipment, Vendor } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Package,
  Plus,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  Truck
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function VendorDashboard() {
  const { vendor } = useAuth();
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (vendor) {
      fetchShipments();
    }
  }, [vendor]);

  const fetchShipments = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from('shipments')
      .select('*')
      .eq('vendor_id', vendor?.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setShipments(data);
    }

    setLoading(false);
  };

  const pendingCount = shipments.filter(s => s.status === 'loading').length;
  const inTransitCount = shipments.filter(s => s.status === 'in_transit').length;
  const deliveredCount = shipments.filter(s => s.status === 'delivered').length;
  const confirmedCount = shipments.filter(s => s.status === 'confirmed').length;
  const totalRevenue = shipments
    .filter(s => s.status === 'confirmed')
    .reduce((sum, s) => sum + (s.total_amount || 0), 0);

  const recentShipments = shipments.slice(0, 5);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Vendor Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Welcome back, {vendor?.company_name || 'Vendor'}
          </p>
        </div>
        <Link href="/dashboard/shipments/create">
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Create Shipment
          </Button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Shipments</CardTitle>
            <Package className="h-5 w-5 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{shipments.length}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              All time shipments
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending</CardTitle>
            <Clock className="h-5 w-5 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text_gray-900 dark:text-white">{pendingCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Awaiting driver assignment
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">In Transit</CardTitle>
            <Truck className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{inTransitCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Currently on the way
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 dark:text-gray-400">Confirmed</CardTitle>
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 dark:text-white">{confirmedCount}</div>
            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
              Successfully delivered
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Card */}
      <Card className="bg-gradient-to-br from-blue-500 to-blue-700 text-white">
        <CardHeader>
          <CardTitle className="text-white">Total Revenue</CardTitle>
          <CardDescription className="text-blue-100">From confirmed shipments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold">${totalRevenue.toLocaleString()}</div>
          <div className="mt-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            <span className="text-blue-100">+{(confirmedCount / Math.max(shipments.length, 1) * 100).toFixed(0)}% success rate</span>
          </div>
        </CardContent>
      </Card>

      {/* Recent Shipments */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Shipments</CardTitle>
          <CardDescription>Your latest shipment activity</CardDescription>
        </CardHeader>
        <CardContent>
          {recentShipments.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No shipments yet</p>
              <Link href="/dashboard/shipments/create">
                <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                  Create your first shipment
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {recentShipments.map((shipment) => (
                <div
                  key={shipment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-lg">
                      <Package className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">{shipment.shipment_number}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {format(new Date(shipment.created_at), 'MMM dd, yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge
                      variant={
                        shipment.status === 'confirmed' ? 'default' :
                        shipment.status === 'in_transit' ? 'secondary' :
                        shipment.status === 'rejected' ? 'destructive' :
                        'outline'
                      }
                      className="capitalize"
                    >
                      {shipment.status.replace('_', ' ')}
                    </Badge>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      ${shipment.total_amount?.toLocaleString() || 0}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
          {shipments.length > 5 && (
            <Link href="/dashboard/shipments">
              <Button variant="outline" className="w-full mt-4">
                View all shipments
              </Button>
            </Link>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
