'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Package,
  Users,
  MapPin,
  Truck,
  Building2,
  Settings,
  LogOut,
  BarChart3,
  FileText,
  MapPinned,
  PackageCheck,
} from 'lucide-react';

const navigation = {
  admin: [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Shipments', href: '/dashboard/shipments', icon: Package },
    { name: 'Analytics', href: '/dashboard/analytics', icon: BarChart3 },
    { name: 'Vendors', href: '/dashboard/vendors', icon: Building2 },
    { name: 'Drivers', href: '/dashboard/drivers', icon: Truck },
    { name: 'Sites', href: '/dashboard/sites', icon: MapPin },
  ],
  vendor: [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Create Shipment', href: '/dashboard/shipments/create', icon: Package },
    { name: 'My Shipments', href: '/dashboard/shipments', icon: FileText },
    { name: 'Tracking', href: '/dashboard/tracking', icon: MapPinned },
  ],
  driver: [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Assigned Shipments', href: '/dashboard/assignments', icon: Package },
    { name: 'Active Trip', href: '/dashboard/trip', icon: Truck },
    { name: 'History', href: '/dashboard/history', icon: FileText },
  ],
  site_manager: [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'Incoming Shipments', href: '/dashboard/incoming', icon: Package },
    { name: 'Receiving', href: '/dashboard/receiving', icon: PackageCheck },
    { name: 'History', href: '/dashboard/history', icon: FileText },
  ],
};

export function Sidebar() {
  const pathname = usePathname();
  const { profile, signOut } = useAuth();

  const role = profile?.role || 'vendor';
  const navItems = navigation[role] || navigation.vendor;

  return (
    <div className="flex h-full w-64 flex-col bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2 px-6 border-b border-gray-200 dark:border-gray-800">
        <div className="bg-blue-600 p-2 rounded-lg">
          <Building2 className="h-6 w-6 text-white" />
        </div>
        <span className="text-xl font-bold text-gray-900 dark:text-white">BuildTrack</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-4 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200',
                isActive
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                  : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </Link>
          );
        })}
      </nav>

      {/* User section */}
      <div className="border-t border-gray-200 dark:border-gray-800 p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center">
            <span className="text-sm font-medium text-white">
              {profile?.full_name?.charAt(0).toUpperCase() || 'U'}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
              {profile?.full_name || 'User'}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
              {profile?.role?.replace('_', ' ') || 'User'}
            </p>
          </div>
        </div>
        <button
          onClick={signOut}
          className="flex items-center gap-2 w-full rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800 transition-colors"
        >
          <LogOut className="h-4 w-4" />
          Sign out
        </button>
      </div>
    </div>
  );
}
