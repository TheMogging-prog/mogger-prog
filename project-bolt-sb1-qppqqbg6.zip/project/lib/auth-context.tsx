'use client';

import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { Profile, Vendor, Driver, Site, UserSession } from './types';
import { useRouter } from 'next/navigation';

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  vendor: Vendor | null;
  driver: Driver | null;
  site: Site | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string, role: string, additionalData?: any) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  refreshSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [driver, setDriver] = useState<Driver | null>(null);
  const [site, setSite] = useState<Site | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const fetchUserData = async (userId: string) => {
    try {
      // Fetch profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (profileError) throw profileError;
      setProfile(profileData);

      if (!profileData) return;

      // Fetch role-specific data
      if (profileData.role === 'vendor') {
        const { data: vendorData } = await supabase
          .from('vendors')
          .select('*')
          .eq('profile_id', userId)
          .maybeSingle();
        setVendor(vendorData);
      } else if (profileData.role === 'driver') {
        const { data: driverData } = await supabase
          .from('drivers')
          .select('*')
          .eq('profile_id', userId)
          .maybeSingle();
        setDriver(driverData);
      } else if (profileData.role === 'site_manager') {
        const { data: siteData } = await supabase
          .from('sites')
          .select('*')
          .eq('manager_id', userId)
          .maybeSingle();
        setSite(siteData);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);

      if (session?.user) {
        await fetchUserData(session.user.id);
      }

      setLoading(false);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);

        if (session?.user) {
          await fetchUserData(session.user.id);
        } else {
          setProfile(null);
          setVendor(null);
          setDriver(null);
          setSite(null);
        }

        setLoading(false);
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (!error) {
      router.push('/dashboard');
    }

    return { error };
  };

  const signUp = async (
    email: string,
    password: string,
    fullName: string,
    role: string,
    additionalData?: any
  ) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          role: role,
        },
      },
    });

    if (!error && data.user) {
      // If vendor, create vendor record
      if (role === 'vendor' && additionalData) {
        await supabase.from('vendors').insert({
          profile_id: data.user.id,
          company_name: additionalData.companyName || fullName,
          company_address: additionalData.companyAddress,
          gst_number: additionalData.gstNumber,
          contact_person: fullName,
        });
      }
      // If driver, create driver record
      else if (role === 'driver' && additionalData) {
        await supabase.from('drivers').insert({
          profile_id: data.user.id,
          license_number: additionalData.licenseNumber,
          vehicle_number: additionalData.vehicleNumber,
          vehicle_type: additionalData.vehicleType,
        });
      }

      router.push('/dashboard');
    }

    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setVendor(null);
    setDriver(null);
    setSite(null);
    router.push('/login');
  };

  const refreshSession = async () => {
    if (user) {
      await fetchUserData(user.id);
    }
  };

  const value = {
    user,
    profile,
    vendor,
    driver,
    site,
    loading,
    signIn,
    signUp,
    signOut,
    refreshSession,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
