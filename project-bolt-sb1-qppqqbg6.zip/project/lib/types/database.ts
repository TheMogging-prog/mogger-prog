export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          role: 'admin' | 'vendor' | 'driver' | 'site_manager';
          phone: string | null;
          avatar_url: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          role?: 'admin' | 'vendor' | 'driver' | 'site_manager';
          phone?: string | null;
          avatar_url?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          role?: 'admin' | 'vendor' | 'driver' | 'site_manager';
          phone?: string | null;
          avatar_url?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      vendors: {
        Row: {
          id: string;
          profile_id: string | null;
          company_name: string;
          company_address: string | null;
          gst_number: string | null;
          contact_person: string | null;
          is_verified: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          profile_id?: string | null;
          company_name: string;
          company_address?: string | null;
          gst_number?: string | null;
          contact_person?: string | null;
          is_verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          profile_id?: string | null;
          company_name?: string;
          company_address?: string | null;
          gst_number?: string | null;
          contact_person?: string | null;
          is_verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      drivers: {
        Row: {
          id: string;
          profile_id: string | null;
          license_number: string | null;
          license_expiry: string | null;
          vehicle_number: string | null;
          vehicle_type: string | null;
          is_available: boolean;
          current_location: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          profile_id?: string | null;
          license_number?: string | null;
          license_expiry?: string | null;
          vehicle_number?: string | null;
          vehicle_type?: string | null;
          is_available?: boolean;
          current_location?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          profile_id?: string | null;
          license_number?: string | null;
          license_expiry?: string | null;
          vehicle_number?: string | null;
          vehicle_type?: string | null;
          is_available?: boolean;
          current_location?: Json;
          created_at?: string;
          updated_at?: string;
        };
      };
      sites: {
        Row: {
          id: string;
          manager_id: string | null;
          site_name: string;
          site_address: string | null;
          site_code: string;
          gps_coordinates: Json;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          manager_id?: string | null;
          site_name: string;
          site_address?: string | null;
          site_code: string;
          gps_coordinates?: Json;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          manager_id?: string | null;
          site_name?: string;
          site_address?: string | null;
          site_code?: string;
          gps_coordinates?: Json;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      shipments: {
        Row: {
          id: string;
          shipment_number: string;
          vendor_id: string | null;
          driver_id: string | null;
          site_id: string | null;
          status: 'loading' | 'in_transit' | 'delivered' | 'confirmed' | 'rejected';
          truck_number: string | null;
          estimated_delivery: string | null;
          actual_delivery: string | null;
          total_amount: number;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          shipment_number?: string;
          vendor_id?: string | null;
          driver_id?: string | null;
          site_id?: string | null;
          status?: 'loading' | 'in_transit' | 'delivered' | 'confirmed' | 'rejected';
          truck_number?: string | null;
          estimated_delivery?: string | null;
          actual_delivery?: string | null;
          total_amount?: number;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          shipment_number?: string;
          vendor_id?: string | null;
          driver_id?: string | null;
          site_id?: string | null;
          status?: 'loading' | 'in_transit' | 'delivered' | 'confirmed' | 'rejected';
          truck_number?: string | null;
          estimated_delivery?: string | null;
          actual_delivery?: string | null;
          total_amount?: number;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      shipment_materials: {
        Row: {
          id: string;
          shipment_id: string;
          material_name: string;
          material_type: string | null;
          quantity: number;
          unit: string;
          unit_price: number;
          total_price: number;
          description: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          shipment_id: string;
          material_name: string;
          material_type?: string | null;
          quantity: number;
          unit: string;
          unit_price?: number;
          total_price?: number;
          description?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          shipment_id?: string;
          material_name?: string;
          material_type?: string | null;
          quantity?: number;
          unit?: string;
          unit_price?: number;
          total_price?: number;
          description?: string | null;
          created_at?: string;
        };
      };
      shipment_photos: {
        Row: {
          id: string;
          shipment_id: string;
          photo_url: string;
          photo_type: 'material' | 'received' | 'damage' | 'other';
          description: string | null;
          uploaded_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          shipment_id: string;
          photo_url: string;
          photo_type: 'material' | 'received' | 'damage' | 'other';
          description?: string | null;
          uploaded_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          shipment_id?: string;
          photo_url?: string;
          photo_type?: 'material' | 'received' | 'damage' | 'other';
          description?: string | null;
          uploaded_by?: string | null;
          created_at?: string;
        };
      };
      shipment_bills: {
        Row: {
          id: string;
          shipment_id: string;
          bill_url: string;
          bill_number: string | null;
          bill_type: 'original' | 'received';
          amount: number;
          uploaded_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          shipment_id: string;
          bill_url: string;
          bill_number?: string | null;
          bill_type: 'original' | 'received';
          amount?: number;
          uploaded_by?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          shipment_id?: string;
          bill_url?: string;
          bill_number?: string | null;
          bill_type?: 'original' | 'received';
          amount?: number;
          uploaded_by?: string | null;
          created_at?: string;
        };
      };
      shipment_tracking: {
        Row: {
          id: string;
          shipment_id: string;
          latitude: number;
          longitude: number;
          location_name: string | null;
          recorded_at: string;
          driver_id: string | null;
        };
        Insert: {
          id?: string;
          shipment_id: string;
          latitude: number;
          longitude: number;
          location_name?: string | null;
          recorded_at?: string;
          driver_id?: string | null;
        };
        Update: {
          id?: string;
          shipment_id?: string;
          latitude?: number;
          longitude?: number;
          location_name?: string | null;
          recorded_at?: string;
          driver_id?: string | null;
        };
      };
      delivery_confirmations: {
        Row: {
          id: string;
          shipment_id: string;
          site_manager_id: string | null;
          status: 'confirmed' | 'rejected';
          notes: string | null;
          gps_location: Json;
          created_at: string;
        };
        Insert: {
          id?: string;
          shipment_id: string;
          site_manager_id?: string | null;
          status: 'confirmed' | 'rejected';
          notes?: string | null;
          gps_location?: Json;
          created_at?: string;
        };
        Update: {
          id?: string;
          shipment_id?: string;
          site_manager_id?: string | null;
          status?: 'confirmed' | 'rejected';
          notes?: string | null;
          gps_location?: Json;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}
