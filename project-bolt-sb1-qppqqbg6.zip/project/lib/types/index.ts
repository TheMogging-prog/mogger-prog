import { Database } from './database';

type Tables = Database['public']['Tables'];

export type Profile = Tables['profiles']['Row'];
export type Vendor = Tables['vendors']['Row'];
export type Driver = Tables['drivers']['Row'];
export type Site = Tables['sites']['Row'];
export type Shipment = Tables['shipments']['Row'];
export type ShipmentMaterial = Tables['shipment_materials']['Row'];
export type ShipmentPhoto = Tables['shipment_photos']['Row'];
export type ShipmentBill = Tables['shipment_bills']['Row'];
export type ShipmentTracking = Tables['shipment_tracking']['Row'];
export type DeliveryConfirmation = Tables['delivery_confirmations']['Row'];

export type UserRole = 'admin' | 'vendor' | 'driver' | 'site_manager';
export type ShipmentStatus = 'loading' | 'in_transit' | 'delivered' | 'confirmed' | 'rejected';
export type PhotoType = 'material' | 'received' | 'damage' | 'other';
export type BillType = 'original' | 'received';

export interface ShipmentWithDetails extends Shipment {
  vendor?: Vendor & { profile?: Profile };
  driver?: Driver & { profile?: Profile };
  site?: Site & { manager?: Profile };
  materials?: ShipmentMaterial[];
  photos?: ShipmentPhoto[];
  bills?: ShipmentBill[];
  tracking?: ShipmentTracking[];
  confirmation?: DeliveryConfirmation;
}

export interface UserSession {
  user: Profile | null;
  vendor: Vendor | null;
  driver: Driver | null;
  site: Site | null;
}
