import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Check if admin already exists
    const { data: existingAdmin } = await supabase
      .from("profiles")
      .select("*")
      .eq("email", "admin@buildtrack.com")
      .maybeSingle();

    if (existingAdmin) {
      // User exists, let's update their password to ensure it's correct
      const { data: authUsers } = await supabase.auth.admin.listUsers();
      const adminAuthUser = authUsers?.users?.find(u => u.email === "admin@buildtrack.com");

      if (adminAuthUser) {
        await supabase.auth.admin.updateUserById(adminAuthUser.id, {
          password: "Admin@123",
          email_confirm: true
        });
      }

      return new Response(
        JSON.stringify({
          message: "Users already exist. Passwords have been reset to defaults.",
          users: [
            { email: "admin@buildtrack.com", password: "Admin@123", role: "admin" },
            { email: "vendor@example.com", password: "Vendor@123", role: "vendor" },
            { email: "driver@example.com", password: "Driver@123", role: "driver" },
            { email: "sitemanager@example.com", password: "Site@123", role: "site_manager" },
          ],
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Create admin user using admin API for better control
    const { data: adminData, error: adminError } = await supabase.auth.admin.createUser({
      email: "admin@buildtrack.com",
      password: "Admin@123",
      email_confirm: true,
      user_metadata: {
        full_name: "Admin User",
        role: "admin",
      },
    });

    if (adminError) {
      console.error("Admin creation error:", adminError);
      throw adminError;
    }

    // Create vendor user
    const { data: vendorData, error: vendorError } = await supabase.auth.admin.createUser({
      email: "vendor@example.com",
      password: "Vendor@123",
      email_confirm: true,
      user_metadata: {
        full_name: "ABC Materials Inc",
        role: "vendor",
      },
    });

    if (!vendorError && vendorData.user) {
      await supabase.from("vendors").insert({
        profile_id: vendorData.user.id,
        company_name: "ABC Construction Materials",
        company_address: "123 Industrial Area, Mumbai",
        gst_number: "GST12345678",
        contact_person: "ABC Materials Inc",
        is_verified: true,
      });
    }

    // Create driver user
    const { data: driverData, error: driverError } = await supabase.auth.admin.createUser({
      email: "driver@example.com",
      password: "Driver@123",
      email_confirm: true,
      user_metadata: {
        full_name: "John Driver",
        role: "driver",
      },
    });

    if (!driverError && driverData.user) {
      await supabase.from("drivers").insert({
        profile_id: driverData.user.id,
        license_number: "DL12345678",
        vehicle_number: "MH12AB1234",
        vehicle_type: "Truck",
        is_available: true,
      });
    }

    // Create site manager user
    const { data: siteManagerData, error: siteManagerError } = await supabase.auth.admin.createUser({
      email: "sitemanager@example.com",
      password: "Site@123",
      email_confirm: true,
      user_metadata: {
        full_name: "Site Manager",
        role: "site_manager",
      },
    });

    if (!siteManagerError && siteManagerData.user) {
      await supabase.from("sites").insert({
        manager_id: siteManagerData.user.id,
        site_name: "Main Construction Site",
        site_address: "456 Construction Hub, Delhi",
        site_code: "SITE001",
        gps_coordinates: { latitude: 28.6139, longitude: 77.209 },
        is_active: true,
      });
    }

    return new Response(
      JSON.stringify({
        message: "Setup complete! Default users created successfully.",
        users: [
          { email: "admin@buildtrack.com", password: "Admin@123", role: "admin" },
          { email: "vendor@example.com", password: "Vendor@123", role: "vendor" },
          { email: "driver@example.com", password: "Driver@123", role: "driver" },
          { email: "sitemanager@example.com", password: "Site@123", role: "site_manager" },
        ],
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("Setup error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
