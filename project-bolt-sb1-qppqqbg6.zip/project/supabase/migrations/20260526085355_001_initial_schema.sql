/*
  # Initial BuildTrack Schema

  1. New Tables
    - `profiles`: User profiles with role-based access
      - `id` (uuid, primary key, references auth.users)
      - `email` (text, unique)
      - `full_name` (text)
      - `role` (text: admin, vendor, driver, site_manager)
      - `phone` (text)
      - `avatar_url` (text)
      - `is_active` (boolean)
      - `created_at`, `updated_at` (timestamps)
    
    - `vendors`: Vendor company information
      - `id` (uuid, primary key)
      - `profile_id` (uuid, references profiles)
      - `company_name` (text)
      - `company_address` (text)
      - `gst_number` (text)
      - `contact_person` (text)
      - `is_verified` (boolean)
      - `created_at`, `updated_at` (timestamps)
    
    - `drivers`: Driver information
      - `id` (uuid, primary key)
      - `profile_id` (uuid, references profiles)
      - `license_number` (text)
      - `license_expiry` (date)
      - `vehicle_number` (text)
      - `vehicle_type` (text)
      - `is_available` (boolean)
      - `current_location` (jsonb)
      - `created_at`, `updated_at` (timestamps)
    
    - `sites`: Construction site information
      - `id` (uuid, primary key)
      - `manager_id` (uuid, references profiles)
      - `site_name` (text)
      - `site_address` (text)
      - `site_code` (text, unique)
      - `gps_coordinates` (jsonb)
      - `is_active` (boolean)
      - `created_at`, `updated_at` (timestamps)
    
    - `shipments`: Main shipment tracking table
      - `id` (uuid, primary key)
      - `shipment_number` (text, unique)
      - `vendor_id` (uuid, references vendors)
      - `driver_id` (uuid, references drivers)
      - `site_id` (uuid, references sites)
      - `status` (text: loading, in_transit, delivered, confirmed, rejected)
      - `truck_number` (text)
      - `estimated_delivery` (timestamp)
      - `actual_delivery` (timestamp)
      - `total_amount` (decimal)
      - `notes` (text)
      - `created_at`, `updated_at` (timestamps)
    
    - `shipment_materials`: Materials in each shipment
      - `id` (uuid, primary key)
      - `shipment_id` (uuid, references shipments)
      - `material_name` (text)
      - `material_type` (text)
      - `quantity` (decimal)
      - `unit` (text)
      - `unit_price` (decimal)
      - `total_price` (decimal)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `shipment_photos`: Photos for shipments
      - `id` (uuid, primary key)
      - `shipment_id` (uuid, references shipments)
      - `photo_url` (text)
      - `photo_type` (text: material, received, damage)
      - `description` (text)
      - `uploaded_by` (uuid, references profiles)
      - `created_at` (timestamp)
    
    - `shipment_bills`: Bills/invoices for shipments
      - `id` (uuid, primary key)
      - `shipment_id` (uuid, references shipments)
      - `bill_url` (text)
      - `bill_number` (text)
      - `bill_type` (text: original, received)
      - `amount` (decimal)
      - `uploaded_by` (uuid, references profiles)
      - `created_at` (timestamp)
    
    - `shipment_tracking`: GPS tracking updates
      - `id` (uuid, primary key)
      - `shipment_id` (uuid, references shipments)
      - `latitude` (decimal)
      - `longitude` (decimal)
      - `location_name` (text)
      - `recorded_at` (timestamp)
      - `driver_id` (uuid, references drivers)
    
    - `delivery_confirmations`: Site manager confirmations
      - `id` (uuid, primary key)
      - `shipment_id` (uuid, references shipments)
      - `site_manager_id` (uuid, references profiles)
      - `status` (text: confirmed, rejected)
      - `notes` (text)
      - `gps_location` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Policies restrict access based on user roles and ownership
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'vendor', 'driver', 'site_manager')),
  phone text,
  avatar_url text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Vendors table
CREATE TABLE IF NOT EXISTS vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  company_name text NOT NULL,
  company_address text,
  gst_number text,
  contact_person text,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Drivers table
CREATE TABLE IF NOT EXISTS drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
  license_number text,
  license_expiry date,
  vehicle_number text,
  vehicle_type text,
  is_available boolean DEFAULT true,
  current_location jsonb DEFAULT '{"latitude": null, "longitude": null}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sites table
CREATE TABLE IF NOT EXISTS sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  manager_id uuid UNIQUE REFERENCES profiles(id) ON DELETE SET NULL,
  site_name text NOT NULL,
  site_address text,
  site_code text UNIQUE NOT NULL,
  gps_coordinates jsonb DEFAULT '{"latitude": null, "longitude": null}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Generate unique shipment numbers
CREATE OR REPLACE FUNCTION generate_shipment_number()
RETURNS text AS $$
DECLARE
  seq_num integer;
  shipment_num text;
BEGIN
  seq_num := nextval('shipment_seq');
  shipment_num := 'SHP-' || to_char(now(), 'YYYYMMDD') || '-' || lpad(seq_num::text, 6, '0');
  RETURN shipment_num;
END;
$$ LANGUAGE plpgsql;

CREATE SEQUENCE IF NOT EXISTS shipment_seq START 1;

-- Shipments table
CREATE TABLE IF NOT EXISTS shipments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_number text UNIQUE DEFAULT generate_shipment_number(),
  vendor_id uuid REFERENCES vendors(id) ON DELETE SET NULL,
  driver_id uuid REFERENCES drivers(id) ON DELETE SET NULL,
  site_id uuid REFERENCES sites(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'loading' CHECK (status IN ('loading', 'in_transit', 'delivered', 'confirmed', 'rejected')),
  truck_number text,
  estimated_delivery timestamptz,
  actual_delivery timestamptz,
  total_amount decimal(12,2) DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Shipment materials
CREATE TABLE IF NOT EXISTS shipment_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES shipments(id) ON DELETE CASCADE,
  material_name text NOT NULL,
  material_type text,
  quantity decimal(10,2) NOT NULL,
  unit text NOT NULL,
  unit_price decimal(10,2) DEFAULT 0,
  total_price decimal(12,2) DEFAULT 0,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Shipment photos
CREATE TABLE IF NOT EXISTS shipment_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES shipments(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  photo_type text NOT NULL CHECK (photo_type IN ('material', 'received', 'damage', 'other')),
  description text,
  uploaded_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Shipment bills
CREATE TABLE IF NOT EXISTS shipment_bills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES shipments(id) ON DELETE CASCADE,
  bill_url text NOT NULL,
  bill_number text,
  bill_type text NOT NULL CHECK (bill_type IN ('original', 'received')),
  amount decimal(12,2) DEFAULT 0,
  uploaded_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Shipment tracking
CREATE TABLE IF NOT EXISTS shipment_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES shipments(id) ON DELETE CASCADE,
  latitude decimal(10,8) NOT NULL,
  longitude decimal(11,8) NOT NULL,
  location_name text,
  recorded_at timestamptz DEFAULT now(),
  driver_id uuid REFERENCES drivers(id) ON DELETE SET NULL
);

-- Delivery confirmations
CREATE TABLE IF NOT EXISTS delivery_confirmations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id uuid REFERENCES shipments(id) ON DELETE CASCADE,
  site_manager_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  status text NOT NULL CHECK (status IN ('confirmed', 'rejected')),
  notes text,
  gps_location jsonb DEFAULT '{"latitude": null, "longitude": null}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE sites ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipments ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipment_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipment_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipment_bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipment_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE delivery_confirmations ENABLE ROW LEVEL SECURITY;

-- Helper function to check user role
CREATE OR REPLACE FUNCTION is_user_role(check_role text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = check_role
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can insert profiles"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (is_user_role('admin'));

-- Vendors policies
CREATE POLICY "Vendors are viewable by authenticated users"
  ON vendors FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Vendors can manage own profile"
  ON vendors FOR ALL
  TO authenticated
  USING (profile_id = auth.uid() OR is_user_role('admin'))
  WITH CHECK (profile_id = auth.uid() OR is_user_role('admin'));

-- Drivers policies
CREATE POLICY "Drivers are viewable by authenticated users"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Drivers can update own location"
  ON drivers FOR UPDATE
  TO authenticated
  USING (profile_id = auth.uid())
  WITH CHECK (profile_id = auth.uid());

CREATE POLICY "Admins can manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (is_user_role('admin'))
  WITH CHECK (is_user_role('admin'));

-- Sites policies
CREATE POLICY "Sites are viewable by authenticated users"
  ON sites FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Site managers can view assigned site"
  ON sites FOR SELECT
  TO authenticated
  USING (manager_id = auth.uid() OR is_user_role('admin'));

CREATE POLICY "Admins can manage sites"
  ON sites FOR ALL
  TO authenticated
  USING (is_user_role('admin'))
  WITH CHECK (is_user_role('admin'));

-- Shipments policies
CREATE POLICY "Shipment vendors can view own shipments"
  ON shipments FOR SELECT
  TO authenticated
  USING (
    vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
    OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
    OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
    OR is_user_role('admin')
  );

CREATE POLICY "Vendors can create shipments"
  ON shipments FOR INSERT
  TO authenticated
  WITH CHECK (
    vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
    OR is_user_role('admin')
  );

CREATE POLICY "Vendors drivers and admins can update shipments"
  ON shipments FOR UPDATE
  TO authenticated
  USING (
    vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
    OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
    OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
    OR is_user_role('admin')
  )
  WITH CHECK (
    vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
    OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
    OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
    OR is_user_role('admin')
  );

-- Shipment materials policies (inherit from shipments)
CREATE POLICY "Material access based on shipment"
  ON shipment_materials FOR SELECT
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
        OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Material insert based on shipment"
  ON shipment_materials FOR INSERT
  TO authenticated
  WITH CHECK (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Material update based on shipment"
  ON shipment_materials FOR UPDATE
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Material delete based on shipment"
  ON shipment_materials FOR DELETE
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

-- Shipment photos policies
CREATE POLICY "Photos readable by shipment participants"
  ON shipment_photos FOR SELECT
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
        OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Photos insertable by authenticated users"
  ON shipment_photos FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- Shipment bills policies
CREATE POLICY "Bills readable by shipment participants"
  ON shipment_bills FOR SELECT
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
        OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Bills insertable by authenticated users"
  ON shipment_bills FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- Shipment tracking policies
CREATE POLICY "Tracking readable by shipment participants"
  ON shipment_tracking FOR SELECT
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
        OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Drivers can insert tracking"
  ON shipment_tracking FOR INSERT
  TO authenticated
  WITH CHECK (
    driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
  );

-- Delivery confirmations policies
CREATE POLICY "Confirmations readable by shipment participants"
  ON delivery_confirmations FOR SELECT
  TO authenticated
  USING (
    shipment_id IN (
      SELECT id FROM shipments WHERE
        vendor_id IN (SELECT id FROM vendors WHERE profile_id = auth.uid())
        OR driver_id IN (SELECT id FROM drivers WHERE profile_id = auth.uid())
        OR site_id IN (SELECT id FROM sites WHERE manager_id = auth.uid())
        OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
    )
  );

CREATE POLICY "Site managers can create confirmations"
  ON delivery_confirmations FOR INSERT
  TO authenticated
  WITH CHECK (
    site_manager_id = auth.uid()
  );

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_shipments_vendor ON shipments(vendor_id);
CREATE INDEX IF NOT EXISTS idx_shipments_driver ON shipments(driver_id);
CREATE INDEX IF NOT EXISTS idx_shipments_site ON shipments(site_id);
CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(status);
CREATE INDEX IF NOT EXISTS idx_shipments_created ON shipments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tracking_shipment ON shipment_tracking(shipment_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_materials_shipment ON shipment_materials(shipment_id);
CREATE INDEX IF NOT EXISTS idx_photos_shipment ON shipment_photos(shipment_id);
CREATE INDEX IF NOT EXISTS idx_bills_shipment ON shipment_bills(shipment_id);
CREATE INDEX IF NOT EXISTS idx_confirmations_shipment ON delivery_confirmations(shipment_id);

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'New User'),
    COALESCE(NEW.raw_user_meta_data->>'role', 'vendor')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Insert default admin user (will be created by auth system separately)
-- We'll create the admin via edge function to ensure proper auth setup